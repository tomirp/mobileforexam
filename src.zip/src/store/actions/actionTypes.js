export const ADD_PLACE = 'ADD_PLACE'
export const DELETE_PLACE = 'DELETE_PLACE'
export const CREATE_DATA = 'CREATE_DATA'
export const EDIT_DATA = 'EDIT_DATA'


export const LOGIN_USER = 'LOGIN_USER'
export const LOGOUT_USER = 'LOGOUT_USER'